/*
 * These are the definitions for phase 3 of the project
 */

#ifndef _PHASE3_H
#define _PHASE3_H

/* MAXSEMS is defined in phase2.h spring04 */
#define MAXSEMS         200

#endif /* _PHASE3_H */





